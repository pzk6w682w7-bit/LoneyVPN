import 'package:flutter_test/flutter_test.dart';
import 'package:loney_vpn/app.dart';

void main() {
  testWidgets('shows LoneyVPN home screen', (tester) async {
    await tester.pumpWidget(const LoneyVpnApp());
    expect(find.text('LoneyVPN'), findsOneWidget);
    expect(find.text('Отключено'), findsOneWidget);
  });
}
