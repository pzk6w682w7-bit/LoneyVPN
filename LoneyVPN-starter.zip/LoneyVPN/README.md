# LoneyVPN — Blue Neon Edition

Flutter starter project for Android and iOS.

## Current state

This is a UI prototype / starter scaffold:
- Blue Neon dark theme
- Home screen
- Demo server list
- Settings screen
- VPN service interface abstraction
- Demo-only connect/disconnect state

**Important:** the demo service does not create a VPN tunnel, encrypt traffic, or connect to any server. Do not present it as a working VPN.

## Requirements

- Flutter SDK (stable)
- Android Studio / Android SDK for Android builds
- macOS + Xcode for iOS builds and signing

## Run

```bash
flutter pub get
flutter run
```

## Build Android APK

```bash
flutter build apk --release
```

## iOS

iOS builds require macOS, Xcode, Apple signing, and a Network Extension / Packet Tunnel implementation with the appropriate entitlements and provisioning. A normal Flutter screen alone cannot provide system-wide VPN functionality.

## Next engineering steps

1. Decide and audit the VPN core and its licensing.
2. Implement Android `VpnService` integration.
3. Implement iOS Packet Tunnel provider and required entitlements.
4. Add secure profile import and validation.
5. Add connection-state/error reporting and tests.
6. Never embed private server credentials or subscription secrets in source control.

## Repository

https://github.com/pzk6w682w7-bit/LoneyVPN
