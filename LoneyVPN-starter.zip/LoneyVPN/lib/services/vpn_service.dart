import '../models/vpn_server.dart';

enum VpnStatus { disconnected, connecting, connected, disconnecting, error }

/// UI-facing VPN contract. A real implementation must be provided by a
/// separately reviewed native VPN integration for Android and iOS.
abstract interface class VpnService {
  VpnStatus get status;
  Future<void> connect(VpnServer server);
  Future<void> disconnect();
}

/// Safe UI preview only. This does NOT create a VPN tunnel or route traffic.
class DemoVpnService implements VpnService {
  @override
  VpnStatus status = VpnStatus.disconnected;

  @override
  Future<void> connect(VpnServer server) async {
    status = VpnStatus.connecting;
    await Future<void>.delayed(const Duration(milliseconds: 500));
    status = VpnStatus.connected;
  }

  @override
  Future<void> disconnect() async {
    status = VpnStatus.disconnecting;
    await Future<void>.delayed(const Duration(milliseconds: 250));
    status = VpnStatus.disconnected;
  }
}
