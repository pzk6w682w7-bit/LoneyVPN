import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/servers_screen.dart';
import 'screens/settings_screen.dart';
import 'theme/blue_theme.dart';

class LoneyVpnApp extends StatefulWidget {
  const LoneyVpnApp({super.key});

  @override
  State<LoneyVpnApp> createState() => _LoneyVpnAppState();
}

class _LoneyVpnAppState extends State<LoneyVpnApp> {
  int _index = 0;

  static const _pages = [
    HomeScreen(),
    ServersScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LoneyVPN',
      debugShowCheckedModeBanner: false,
      theme: BlueTheme.dark,
      home: Scaffold(
        body: SafeArea(child: IndexedStack(index: _index, children: _pages)),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (value) => setState(() => _index = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield), label: 'Главная'),
            NavigationDestination(icon: Icon(Icons.public), label: 'Серверы'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Настройки'),
          ],
        ),
      ),
    );
  }
}
