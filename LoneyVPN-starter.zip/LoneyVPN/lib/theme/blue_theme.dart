import 'package:flutter/material.dart';

class BlueTheme {
  static const navy = Color(0xFF071426);
  static const panel = Color(0xFF102B49);
  static const blue = Color(0xFF269EFF);
  static const cyan = Color(0xFF55C3FF);

  static final dark = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: navy,
    colorScheme: const ColorScheme.dark(
      primary: blue,
      secondary: cyan,
      surface: panel,
    ),
    cardTheme: CardTheme(
      color: panel,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: Color(0xFF0A1D33),
      indicatorColor: Color(0xFF153E65),
    ),
  );
}
