import 'package:flutter/material.dart';
import '../models/vpn_server.dart';
import '../theme/blue_theme.dart';

class ServersScreen extends StatelessWidget {
  const ServersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Серверы', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Демонстрационный список локаций', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 18),
        for (final server in VpnServer.demoServers)
          Card(
            child: ListTile(
              leading: Text(server.flag, style: const TextStyle(fontSize: 30)),
              title: Text(server.country, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${server.name} • ${server.location}'),
              trailing: Text('${server.pingMs} ms', style: const TextStyle(color: BlueTheme.cyan)),
            ),
          ),
      ],
    );
  }
}
