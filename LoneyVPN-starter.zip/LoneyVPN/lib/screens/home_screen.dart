import 'package:flutter/material.dart';
import '../models/vpn_server.dart';
import '../services/vpn_service.dart';
import '../theme/blue_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final VpnService _vpn = DemoVpnService();
  VpnServer _selected = VpnServer.demoServers.first;

  Future<void> _toggle() async {
    if (_vpn.status == VpnStatus.connected) {
      await _vpn.disconnect();
    } else {
      await _vpn.connect(_selected);
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final connected = _vpn.status == VpnStatus.connected;
    final busy = _vpn.status == VpnStatus.connecting || _vpn.status == VpnStatus.disconnecting;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(children: [
          const Icon(Icons.shield, color: BlueTheme.cyan, size: 30),
          const SizedBox(width: 10),
          const Text('LoneyVPN', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const Spacer(),
          const Chip(label: Text('BLUE EDITION')),
        ]),
        const SizedBox(height: 28),
        const Center(child: Text('ДЕМО-РЕЖИМ', style: TextStyle(color: BlueTheme.cyan, letterSpacing: 2, fontWeight: FontWeight.bold))),
        const SizedBox(height: 20),
        Center(
          child: Container(
            width: 190,
            height: 190,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF102B49),
              border: Border.all(color: BlueTheme.blue, width: 3),
              boxShadow: const [BoxShadow(color: Color(0x55269EFF), blurRadius: 28, spreadRadius: 3)],
            ),
            child: Icon(connected ? Icons.shield : Icons.power_settings_new, size: 76, color: BlueTheme.cyan),
          ),
        ),
        const SizedBox(height: 18),
        Center(child: Text(connected ? 'Демо подключено' : 'Отключено', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w700))),
        const SizedBox(height: 6),
        const Center(child: Text('Сейчас VPN-туннель не создаётся', style: TextStyle(color: Colors.white60))),
        const SizedBox(height: 26),
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Выбранный сервер', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 10),
            Row(children: [
              Text(_selected.flag, style: const TextStyle(fontSize: 30)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_selected.country, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                Text(_selected.location, style: const TextStyle(color: Colors.white60)),
              ])),
              Text('${_selected.pingMs} ms', style: const TextStyle(color: BlueTheme.cyan)),
            ]),
          ]),
        )),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: busy ? null : _toggle,
          icon: Icon(connected ? Icons.stop : Icons.power_settings_new),
          label: Text(busy ? 'Подождите…' : connected ? 'Отключить демо' : 'Проверить интерфейс'),
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54)),
        ),
        const SizedBox(height: 14),
        const Text('Важно: кнопка демонстрирует только состояние интерфейса. Для реального VPN нужны серверные параметры и отдельная нативная интеграция Android/iOS.', style: TextStyle(color: Colors.white54, fontSize: 12)),
      ],
    );
  }
}
