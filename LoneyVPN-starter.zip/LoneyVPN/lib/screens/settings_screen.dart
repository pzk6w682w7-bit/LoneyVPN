import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: const [
        Text('Настройки', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        SizedBox(height: 18),
        Card(child: ListTile(leading: Icon(Icons.dns), title: Text('DNS'), subtitle: Text('Будет доступно после интеграции VPN-движка'))),
        Card(child: ListTile(leading: Icon(Icons.tune), title: Text('Протокол'), subtitle: Text('VLESS / Reality — планируется'))),
        Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('О приложении'), subtitle: Text('LoneyVPN Blue Edition • v1.0.0'))),
      ],
    );
  }
}
