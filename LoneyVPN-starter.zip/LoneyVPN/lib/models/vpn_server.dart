class VpnServer {
  const VpnServer({
    required this.id,
    required this.name,
    required this.country,
    required this.flag,
    required this.location,
    required this.pingMs,
  });

  final String id;
  final String name;
  final String country;
  final String flag;
  final String location;
  final int pingMs;

  static const demoServers = <VpnServer>[
    VpnServer(id: 'de-1', name: 'Germany 01', country: 'Германия', flag: '🇩🇪', location: 'Франкфурт', pingMs: 42),
    VpnServer(id: 'fi-1', name: 'Finland 01', country: 'Финляндия', flag: '🇫🇮', location: 'Хельсинки', pingMs: 28),
    VpnServer(id: 'nl-1', name: 'Netherlands 01', country: 'Нидерланды', flag: '🇳🇱', location: 'Амстердам', pingMs: 51),
  ];
}
